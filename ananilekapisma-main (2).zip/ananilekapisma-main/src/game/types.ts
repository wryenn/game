export type AppScreenState = 'title' | 'playing' | 'paused' | 'gameover' | 'exited';

export type MenuSubView =
  | 'home'
  | 'modes'
  | 'characters'
  | 'settings'
  | 'howto'
  | 'online'
  | 'story'
  | 'saga'
  | 'adventure'
  | 'achievements';

export type GameModeId = 'ffa' | 'team' | 'time' | 'chaos' | 'crown' | 'story' | 'saga' | 'adventure';

export type MapId =
  | 'classic'
  | 'towers'
  | 'crumbling'
  | 'hazard'
  | 'story_origin'
  | 'story_crimson'
  | 'story_frost'
  | 'story_lost'
  | 'story_shadow'
  | 'story_tournament'
  | 'story_golden';

export type AiPersonality = 'aggressive' | 'defensive' | 'balanced' | 'chaotic';

export type SlotKind = 'human' | 'bot' | 'off';

export type TeamId = 'A' | 'B';

export type CharacterColorId =
  | 'crimson'
  | 'cobalt'
  | 'emerald'
  | 'amber'
  | 'plum'
  | 'tangerine'
  | 'turquoise'
  | 'gold_pasha'
  | 'shadow_obsidian'
  | 'kirpi';

export type FesStyleId =
  | 'klasik_fes'
  | 'puskullu_fes'
  | 'yeniceri_bork'
  | 'saray_kavuk'
  | 'sultan_taci'
  | 'denizci_bere'
  | 'altin_migfer';

export type MustacheStyleId = 'kaytan' | 'pala' | 'burgu' | 'cember' | 'sultan_sakal';

export type AccessoryId = 'yok' | 'pelerin' | 'kalkan' | 'gozluk' | 'kanat' | 'hale';

export type HeroId =
  | 'pofi'
  | 'tiknaz'
  | 'zeynep'
  | 'kizil_bey'
  | 'karahan'
  | 'leyla'
  | 'karanlik'
  | 'altin_hakan'
  | 'akin';

export type HeroAbilityKind =
  | 'high_spring'
  | 'belly_dash'
  | 'wind_blink'
  | 'flame_burst'
  | 'frost_shield'
  | 'sky_hook'
  | 'shadow_warp'
  | 'gold_quake'
  | 'ship_it';

export interface HeroStats {
  speedMult: number;
  jumpMult: number;
  weightMult: number;
  maxJumps: number;
  iceImmune?: boolean;
  stompPower: number;
}

export interface HeroDef {
  id: HeroId;
  name: string;
  title: string;
  description: string;
  unlockLevel: number;
  abilityName: string;
  abilityDesc: string;
  abilityCooldown: number;
  abilityKind: HeroAbilityKind;
  stats: HeroStats;
  defaultCostume: CostumeConfig;
}

export interface CostumeConfig {
  colorId: CharacterColorId;
  fesStyle: FesStyleId;
  mustacheStyle: MustacheStyleId;
  accessoryId?: AccessoryId;
}

export interface PlayerSlotConfig {
  slotIndex: number; // 0..3
  kind: SlotKind;
  name: string;
  team: TeamId;
  aiPersonality: AiPersonality;
  heroId?: HeroId;
  costume: CostumeConfig;
  look?: HumanLookId;
}

export type HumanLookId = 'akin' | 'devin' | 'ozgur' | 'mert' | 'tuna' | 'ayaz' | 'gokoz' | 'buglord' | 'bug';
export type ScrollTheme = 'cankaya' | 'kizilay' | 'tunali' | 'frost' | 'glitch' | 'tower';

export interface AudioSettings {
  musicVolume: number; // 0..1
  sfxVolume: number; // 0..1
  muted: boolean;
}

export interface PlayerKeyBindings {
  left: string;
  right: string;
  jump: string;
  down: string;
  ability: string;
}

export interface ControlsConfig {
  p1: PlayerKeyBindings;
  p2: PlayerKeyBindings;
  gamepadDeadzone: number; // 0.15 .. 0.45
  jumpCutEnabled: boolean;
  touchControlsEnabled: boolean;
}

export interface GameSettings {
  mode: GameModeId;
  mapId: MapId;
  lives: number; // 1..5 for ffa / team
  roundDurationSec: number; // 45..120 for time attack
  botsEnabled: boolean;
  audio: AudioSettings;
  controls: ControlsConfig;
}

export interface PlatformDef {
  id: string;
  x: number;
  y: number;
  w: number;
  h: number;
  type: 'stone' | 'wood' | 'crumbling' | 'moving' | 'tower';
  oneWay?: boolean;
  moveAxis?: 'x' | 'y';
  moveRange?: number;
  moveSpeed?: number;
  movePhase?: number;
}

export interface PlatformState extends PlatformDef {
  baseX: number;
  baseY: number;
  vx: number;
  vy: number;
  crumbleState: 'solid' | 'shaking' | 'fallen';
  crumbleTimer: number;
}

export type HazardPhase = 'calm' | 'wind_left' | 'wind_right' | 'slippery' | 'cannon';

export interface CannonStrike {
  id: number;
  x: number;
  y: number;
  radius: number;
  telegraphTimer: number; // counts down to 0 before blast
  blastTimer: number; // active explosion visual
  exploded: boolean;
}

export interface PlayerInputState {
  left: boolean;
  right: boolean;
  upHeld: boolean;
  jumpPressed: boolean;
  down: boolean;
  abilityPressed?: boolean;
}

export interface CharacterEntity {
  slotIndex: number;
  heroId: HeroId;
  look?: HumanLookId;
  name: string;
  isBot: boolean;
  aiPersonality: AiPersonality;
  team: TeamId;
  costume: CostumeConfig;
  x: number;
  y: number;
  vx: number;
  vy: number;
  w: number;
  h: number;
  facing: 1 | -1;
  grounded: boolean;
  coyoteTimer: number;
  jumpBufferTimer: number;
  jumpsUsed: number;
  maxJumps: number;
  stunTimer: number;
  pancakeTimer: number;
  invulnTimer: number;
  shieldTimer: number;
  abilityCooldown: number;
  abilityMaxCooldown: number;
  flashTimer: number;
  squashX: number;
  squashY: number;
  jiggleAmp: number;
  jigglePhase: number;
  airTilt: number;
  blinkTimer: number;
  walkCycle: number;
  tasselAngle: number;
  tasselVel: number;
  alive: boolean;
  eliminated: boolean;
  respawnTimer: number;
  lives: number;
  maxLives: number;
  score: number;
  kills: number;
  deaths: number;
  stomps: number;
  jumpsMade: number;
  lastHitBy: number | null;
  lastHitTimer: number;
  aiDecisionTimer: number;
  aiTargetSlot: number | null;
  aiWanderDir: 1 | -1;
}

export interface GameEvent {
  type:
    | 'jump'
    | 'double_jump'
    | 'land'
    | 'stomp'
    | 'bump'
    | 'ko'
    | 'crumble'
    | 'cannon'
    | 'ability';
  x: number;
  y: number;
  slotIndex?: number;
  victimSlot?: number;
  color?: string;
  intensity?: number;
  points?: number;
}

export type AdventureEnemyKind =
  | 'knight'
  | 'mage'
  | 'shadow'
  | 'boss'
  | 'bug'
  | 'mert'
  | 'tuna'
  | 'ayaz'
  | 'gokoz'
  | 'buglord';

export interface AdventureState {
  chapterId: number;
  waves: AdventureEnemyKind[][];
  waveIdx: number;
  waveDelay: number;
  bossSlot: number | null;
  bossName?: string;
  bossMaxHp?: number;
  triggers?: number[];
  nextSlot: number;
  victoryText: string;
  hp: Record<number, number>;
}

export interface StoryMatchRule {
  chapterId: number;
  title: string;
  objectiveLabel: string;
  targetStomps?: number;
  targetScore?: number;
  surviveSeconds?: number;
  defaultHazard?: HazardPhase;
  bossSlot?: number;
}

export interface SimulationState {
  mode: GameModeId;
  mapId: MapId;
  countdown: number;
  worldWidth: number;
  scrollX: number;
  scrollLock: number | null;
  scrollTheme?: ScrollTheme;
  elapsedSec: number;
  timeRemainingSec: number;
  hitstopTimer: number;
  trauma: number;
  hazardPhase: HazardPhase;
  hazardTimer: number;
  windForce: number;
  frictionFactor: number;
  cannons: CannonStrike[];
  nextCannonId: number;
  platforms: PlatformState[];
  players: CharacterEntity[];
  finished: boolean;
  winnerSlot: number | null;
  winnerTeam: TeamId | null;
  winReason: string;
  pendingEvents: GameEvent[];
  storyRule?: StoryMatchRule | null;
  crownHolder?: number | null;
  crownX?: number;
  crownY?: number;
  crownHeld?: Record<number, number>;
  adventure?: AdventureState | null;
}

export interface HudPlayerSummary {
  slotIndex: number;
  heroId: HeroId;
  look?: HumanLookId;
  name: string;
  isBot: boolean;
  team: TeamId;
  colorId: CharacterColorId;
  costume: CostumeConfig;
  lives: number;
  maxLives: number;
  score: number;
  kills: number;
  deaths: number;
  stomps: number;
  jumpsMade: number;
  alive: boolean;
  eliminated: boolean;
  stunned: boolean;
  shielded: boolean;
  abilityCooldown: number;
  abilityMaxCooldown: number;
}

export interface HudSnapshot {
  mode: GameModeId;
  mapId: MapId;
  countdown: number;
  elapsedSec: number;
  timeRemainingSec: number;
  aliveCount: number;
  hazardPhase: HazardPhase;
  storyObjective?: string;
  players: HudPlayerSummary[];
}

export type AchievementId =
  | 'ilk_eleme'
  | 'bes_zipla'
  | 'sifir_hata'
  | 'kafa_avcisi'
  | 'yuz_puan'
  | 'hikaye_kasifi'
  | 'cevrimici_dost';

export interface AchievementDef {
  id: AchievementId;
  title: string;
  description: string;
  badgeText: string;
}

export interface AchievementState {
  unlockedIds: AchievementId[];
  unlockedAt: Partial<Record<AchievementId, number>>;
}

export interface RoundResult {
  mode: GameModeId;
  mapId: MapId;
  durationSec: number;
  winnerSlot: number | null;
  winnerTeam: TeamId | null;
  winReason: string;
  standings: HudPlayerSummary[];
  unlockedAchievements?: AchievementId[];
  storyChapterId?: number;
  storyWon?: boolean;
  sagaLevelId?: number;
  sagaWon?: boolean;
  adventureChapterId?: number;
  adventureWon?: boolean;
  sagaStars?: 0 | 1 | 2 | 3;
  xpEarned?: number;
  leveledUpTo?: number;
}

// Progression & Level Unlocks
export interface PlayerProgression {
  xp: number;
  level: number;
  matchesPlayed: number;
  wins: number;
  totalStomps: number;
  totalKills: number;
}

// Candy-Crush Style Branching Saga Map
export type SagaBranchKind = 'main' | 'side' | 'boss';

export interface SagaMapPos {
  x: number; // 18..82 percentage across map width
  row: number; // 0..10 tier from bottom to top
}

export interface SagaLevelDef {
  id: number; // 1..15
  title: string;
  worldName: string;
  worldColor: string;
  mapId: MapId;
  mode: 'saga';
  lives: number;
  roundDurationSec?: number;
  isBoss?: boolean;
  branchKind: SagaBranchKind;
  branchLabel?: string;
  nextIds: number[];
  mapPos: SagaMapPos;
  objectiveText: string;
  star2Hint: string;
  star3Hint: string;
  rewardXp: number;
  rule: StoryMatchRule;
  rivals: {
    name: string;
    heroId: HeroId;
    aiPersonality: AiPersonality;
    costume: CostumeConfig;
  }[];
  ally?: {
    name: string;
    heroId: HeroId;
    aiPersonality: AiPersonality;
    costume: CostumeConfig;
  };
}

export interface SagaProgress {
  highestUnlockedLevel: number;
  unlockedLevelIds: number[];
  completedLevelIds: number[];
  starsByLevel: Record<number, 1 | 2 | 3>;
  claimedMilestones: number[];
}

// Story Mode (Yedi Kale Krallığı)
export type MoralAlignment = 'mercy' | 'wisdom' | 'might';

export interface StoryDialogueLine {
  speaker: string;
  role: string;
  costume?: CostumeConfig;
  text: string;
  side?: 'left' | 'right';
}

export interface StoryChoiceOption {
  id: string;
  label: string;
  description: string;
  alignment: MoralAlignment;
  secretFound?: string;
  bonusLives?: number;
  responseLine: StoryDialogueLine;
}

export interface StoryChapterDef {
  id: number;
  slug: string;
  title: string;
  subtitle: string;
  mapId: MapId;
  sealName: string;
  loreIntro: string;
  secretLore: string;
  objectiveLabel: string;
  mode: GameModeId;
  lives: number;
  roundDurationSec?: number;
  storyRule: StoryMatchRule;
  rivals: {
    name: string;
    team: TeamId;
    aiPersonality: AiPersonality;
    costume: CostumeConfig;
  }[];
  ally?: {
    name: string;
    aiPersonality: AiPersonality;
    costume: CostumeConfig;
  };
  introDialogue: StoryDialogueLine[];
  choicePrompt: string;
  choices: StoryChoiceOption[];
  victoryDialogue: StoryDialogueLine[];
  unlocksText: string;
  unlockMapId: MapId;
  unlockColorId?: CharacterColorId;
  unlockFesId?: FesStyleId;
}

export interface StoryProgress {
  completedChapters: number[];
  unlockedMaps: MapId[];
  unlockedColors: CharacterColorId[];
  unlockedFes: FesStyleId[];
  secretsFound: string[];
  choicesByChapter: Record<number, string>;
  alignmentCounts: Record<MoralAlignment, number>;
  endingReached: 'unity' | 'guardian' | 'obsidian' | null;
}

// Online WebRTC + Signaling Types
export type PeerTransportStatus = 'connecting' | 'p2p' | 'turn_relay' | 'disconnected';

export interface OnlinePeerInfo {
  peerId: string;
  slotIndex: number;
  name: string;
  costume: CostumeConfig;
  isHost: boolean;
  transport?: PeerTransportStatus;
}

export interface OnlineRoomState {
  code: string;
  hostPeerId: string;
  mode: GameModeId;
  mapId: MapId;
  lives: number;
  roundDurationSec: number;
  botsEnabled: boolean;
  inGame: boolean;
  peers: OnlinePeerInfo[];
}
